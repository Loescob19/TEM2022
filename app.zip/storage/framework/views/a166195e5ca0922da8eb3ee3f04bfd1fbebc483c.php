<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Código')); ?>

            <?php echo e(Form::text('cod_product', $producto->cod_product, ['class' => 'form-control' . ($errors->has('cod_product') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese código del producto'])); ?>

            <?php echo $errors->first('cod_product', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nombre del Producto')); ?>

            <?php echo e(Form::text('nameProd', $producto->nameProd, ['class' => 'form-control' . ($errors->has('nameProd') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese nombre del producto'])); ?>

            <?php echo $errors->first('nameProd', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Descripción')); ?>

            <?php echo e(Form::text('descProd', $producto->descProd, ['class' => 'form-control' . ($errors->has('descProd') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese descripción del producto'])); ?>

            <?php echo $errors->first('descProd', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Tipo')); ?>

            <?php echo e(Form::text('typeProd', $producto->typeProd, ['class' => 'form-control' . ($errors->has('typeProd') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese tipo del producto'])); ?>

            <?php echo $errors->first('typeProd', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Costo')); ?>

            <?php echo e(Form::text('costUnit', $producto->costUnit, ['class' => 'form-control' . ($errors->has('costUnit') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese costo unitario del producto'])); ?>

            <?php echo $errors->first('costUnit', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Existencias')); ?>

            <?php echo e(Form::text('cantExist', $producto->cantExist, ['class' => 'form-control' . ($errors->has('cantExist') ? ' is-invalid' : ''), 'placeholder' => 'Ingrese existencias del producto'])); ?>

            <?php echo $errors->first('cantExist', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lab2CRLE\resources\views/producto/form.blade.php ENDPATH**/ ?>